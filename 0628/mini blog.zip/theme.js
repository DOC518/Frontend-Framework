export const lightTheme = {
    background: "#ffffff",
    text: "#000000",
    postBackground: "#ffffff",
    postBorder: "#cccccc",
    buttonBackground: "#7e57c2",
    buttonText: "#ffffff"
};

export const darkTheme = {
    background: "#000000",
    text: "#ffffff",
    postBackground: "#333333",
    postBorder: "#444444",
    buttonBackground: "#7e57c2",
    buttonText: "#ffffff"
};
