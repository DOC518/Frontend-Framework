import React, { useState, useEffect } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import styled, { ThemeProvider, keyframes } from "styled-components";
import MainPage from './component/page/MainPage';
import PostWritePage from './component/page/PostWritePage';
import PostViewPage from './component/page/PostViewPage';
import initialData from './data.json';
import Button from './component/ui/Button';

const MainTitleText = styled.p`
    font-size: 24px;
    font-weight: bold;
    text-align: center;
    margin: 16px 0;
`;

const Wrapper = styled.div`
    background-color: ${({ theme }) => theme.background};
    color: ${({ theme }) => theme.text};
    min-height: 100vh;
    display: flex;
    flex-direction: column;
    align-items: center;
`;

const lightTheme = {
    background: "#fff",
    text: "#000",
    buttonBackground: "#007bff",
    buttonText: "#fff",
    buttonHoverBackground: "#0056b3",
    buttonActiveBackground: "#003f7f"
};

const darkTheme = {
    background: "#121212",
    text: "#fff",
    buttonBackground: "#bb86fc",
    buttonText: "#000",
    buttonHoverBackground: "#9f67d3",
    buttonActiveBackground: "#7b48a1"
};

const fadeIn = keyframes`
    from {
        opacity: 0;
    }
    to {
        opacity: 1;
    }
`;

const fadeOut = keyframes`
    from {
        opacity: 1;
    }
    to {
        opacity: 0;
    }
`;

const TimeDisplay = styled.div`
    font-size: 16px;
    margin-top: 16px;
    animation: ${fadeIn} 1s ease-in-out;
`;

const WelcomeBox = styled.div`
    font-size: 20px;
    margin-top: 16px;
    padding: 10px;
    border: 1px solid ${({ theme }) => theme.text};
    border-radius: 8px;
    animation: ${({ isVisible }) => (isVisible ? fadeIn : fadeOut)} 2s ease-in-out;
    opacity: ${({ isVisible }) => (isVisible ? 1 : 0)};
    transition: opacity 2s ease-in-out;
`;

function App() {
    const [posts, setPosts] = useState(() => {
        const savedPosts = JSON.parse(localStorage.getItem('posts')) || [];
        const combinedPosts = [...initialData, ...savedPosts];
        return combinedPosts;
    });

    const [isDarkMode, setIsDarkMode] = useState(() => {
        const savedTheme = localStorage.getItem('theme');
        return savedTheme ? JSON.parse(savedTheme) : false;
    });

    const [currentTime, setCurrentTime] = useState(new Date());
    const [isVisible, setIsVisible] = useState(true);

    useEffect(() => {
        const savedPosts = posts.filter(post => post.id > initialData.length);
        localStorage.setItem('posts', JSON.stringify(savedPosts));
    }, [posts]);

    useEffect(() => {
        localStorage.setItem('theme', JSON.stringify(isDarkMode));
    }, [isDarkMode]);

    useEffect(() => {
        const timer = setInterval(() => {
            setCurrentTime(new Date());
        }, 1000);
        return () => clearInterval(timer);
    }, []);

    useEffect(() => {
        const welcomeTimer = setInterval(() => {
            setIsVisible(prev => !prev);
        }, 5000);
        return () => clearInterval(welcomeTimer);
    }, []);

    const addPost = (title, content) => {
        const newPost = {
            id: posts.length + 1,
            title,
            content,
            comments: [],
        };
        setPosts(prevPosts => [...prevPosts, newPost]);
    };

    const deletePost = (postId) => {
        setPosts(prevPosts => prevPosts.filter(post => post.id !== postId));
    };

    const addComment = (postId, commentContent) => {
        setPosts(prevPosts => prevPosts.map(post => {
            if (post.id === postId) {
                const newComment = {
                    id: post.comments.length + 1,
                    content: commentContent
                };
                return { ...post, comments: [...post.comments, newComment] };
            }
            return post;
        }));
    };

    const deleteComment = (postId, commentId) => {
        setPosts(prevPosts => prevPosts.map(post => {
            if (post.id === postId) {
                return { ...post, comments: post.comments.filter(comment => comment.id !== commentId) };
            }
            return post;
        }));
    };

    const toggleDarkMode = () => {
        setIsDarkMode(prevMode => !prevMode);
    };

    return (
        <ThemeProvider theme={isDarkMode ? darkTheme : lightTheme}>
            <Wrapper>
                <MainTitleText>201929194 곽주영 미니블로그</MainTitleText>
                <Button
                    title={isDarkMode ? "라이트 모드" : "다크 모드"}
                    onClick={toggleDarkMode}
                />
                <TimeDisplay>{currentTime.toLocaleString()}</TimeDisplay>
                <WelcomeBox isVisible={isVisible}>오신 것을 환영합니다</WelcomeBox>
                <BrowserRouter>
                    <Routes>
                        <Route index element={<MainPage posts={posts} deletePost={deletePost} />} />
                        <Route path="post-write" element={<PostWritePage addPost={addPost} />} />
                        <Route path="post/:postId" element={<PostViewPage posts={posts} deletePost={deletePost} addComment={addComment} deleteComment={deleteComment} />} />
                    </Routes>
                </BrowserRouter>
            </Wrapper>
        </ThemeProvider>
    );
}

export default App;
