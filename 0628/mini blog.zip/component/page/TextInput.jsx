import React from 'react';
import styled from 'styled-components';

const Input = styled.textarea`
    width: 100%;
    padding: 8px;
    margin-bottom: 16px;
    border: 1px solid grey;
    border-radius: 4px;
    resize: none;
    box-sizing: border-box;
`;

function TextInput({ height, value, onChange }) {
    return (
        <Input
            style={{ height: `${height}px` }}
            value={value}
            onChange={onChange}
        />
    );
}

export default TextInput;
