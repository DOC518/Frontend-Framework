import React from 'react';
import styled from 'styled-components';
import Button from '../ui/Button';

const CommentContainer = styled.div`
    width: 100%;
    border: 1px solid grey;
    padding: 8px 16px;
    border-radius: 8px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    background-color: ${({ theme }) => theme.background};
    color: ${({ theme }) => theme.text};

    :not(:last-child) {
        margin-bottom: 8px;
    }
`;

const CommentText = styled.p`
    font-size: 16px;
    margin: 0;
`;

const DeleteButton = styled(Button)`
    background-color: red;
    color: white;
    border: none;
    padding: 4px 8px;
    border-radius: 4px;
`;

function CommentList({ comments, deleteComment, postId }) {
    return (
        <div>
            {comments.map((comment) => (
                <CommentContainer key={comment.id}>
                    <CommentText>{comment.content}</CommentText>
                    <DeleteButton
                        title="삭제"
                        onClick={() => deleteComment(postId, comment.id)}
                    />
                </CommentContainer>
            ))}
        </div>
    );
}

export default CommentList;
