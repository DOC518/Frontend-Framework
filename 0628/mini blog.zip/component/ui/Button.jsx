import styled from "styled-components";

const StyledButton = styled.button`
    background-color: ${({ theme }) => theme.buttonBackground};
    color: ${({ theme }) => theme.buttonText};
    border: none;
    border-radius: 4px;
    padding: 10px 20px;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s, transform 0.3s;

    &:hover {
        background-color: ${({ theme }) => theme.buttonHoverBackground};
        transform: scale(1.05);
    }

    &:active {
        background-color: ${({ theme }) => theme.buttonActiveBackground};
        transform: scale(0.95);
    }
`;

function Button({ title, onClick }) {
    return <StyledButton onClick={onClick}>{title}</StyledButton>;
}

export default Button;
